package com.example.contactlist;

import android.view.View;
import android.view.ViewGroup;

public interface CustomAdapterk {
    View getView(int position, View convertView, ViewGroup parent);
}
